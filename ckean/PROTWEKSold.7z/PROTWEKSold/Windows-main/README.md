I recommend you read my file: "Privacy Services List"
Google, Microsoft, Facebook, Apple, are EVIL! Don't let them take away freedom for generations to come! Surveillance is BAD!
