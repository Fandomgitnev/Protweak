# Ghost_Toolbox_1.9.0

Run Ghost Toolbox on any OS <br>
Download the files  <br>
copy paste the "nhcolor.exe" in System32 (this exe is responsible for the colorful text as well as verification that you are running this on Ghost Spectre OS) <br>
now open the ghost_toolbox.cmd as admin <br>
boom! there you go! <br>

![Screenshot](https://user-images.githubusercontent.com/85176292/131864804-c49b0d1e-79d8-4d20-8256-a62f703c1bd7.png)
